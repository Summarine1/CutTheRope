package br.ol.ctr.core;

import static br.ol.ctr.core.Scene.GameState.*;
import br.ol.ctr.entity.AirCushionEntity;
import br.ol.ctr.entity.BackgroundEntity;
import br.ol.ctr.entity.BubbleEntity;
import br.ol.ctr.entity.CandyEntity;
import br.ol.ctr.entity.CurtainEntity;
import br.ol.ctr.entity.FadeEffectEntity;
import br.ol.ctr.entity.GameOverEntity;
import br.ol.ctr.entity.InitializerEntity;
import br.ol.ctr.entity.LevelClearedEntity;
import br.ol.ctr.entity.OLPresentsEntity;
import br.ol.ctr.entity.PetEntity;
import br.ol.ctr.entity.PinRopeEntity;
import br.ol.ctr.entity.RopeEntity;
import br.ol.ctr.entity.SpikesEntity;
import br.ol.ctr.entity.StarEntity;
import br.ol.ctr.entity.TitleEntity;
import br.ol.ctr.model.AirCushion;
import br.ol.ctr.model.Bubble;
import br.ol.ctr.model.Model;
import br.ol.ctr.model.PinRope;
import br.ol.ctr.model.Rope;
import br.ol.ctr.model.Spikes;
import br.ol.ctr.model.Star;
import java.awt.Graphics2D;
import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

/**
 * Scene class.
 * 
 * @author Leonardo Ono (ono.leo@gmail.com)
 */
public class Scene {

    private final Model model = new Model(800, 600, 10);
    protected List<Entity> entities = new ArrayList<Entity>();
    protected List<Entity> levelEntities = new ArrayList<Entity>();

    public static enum GameState { INITIALIZING, OL_PRESENTS, TITLE, LEVEL_SELECT, READY, PLAYING, LEVEL_CLEARED, GAME_OVER }
    private GameState gameState = GameState.INITIALIZING;

    private int currentLevel = 1;
    
    public Scene() {
    }

    public Model getModel() {
        return model;
    }

    public GameState getGameState() {
        return gameState; 
    }

    public void setState(GameState gameState) {
        if (this.gameState != gameState) {
            this.gameState = gameState;
            for (Entity entity : levelEntities) {
                entity.gameStateChanged(gameState);
            }
            for (Entity entity : entities) {
                entity.gameStateChanged(gameState);
            }
        }
    }
    
    public void start() {
        createAllEntities();
        startAllEntities();
    }
    
    private FadeEffectEntity fadeEffect;
    private CurtainEntity curtain;
    private void createAllEntities() {
        fadeEffect = new FadeEffectEntity(this);
        curtain = new CurtainEntity(this);
        
        entities.add(new InitializerEntity(this, fadeEffect));
        entities.add(new OLPresentsEntity(this, fadeEffect));
        entities.add(new TitleEntity(this, fadeEffect, curtain));
        
        entities.add(curtain);
        entities.add(new GameOverEntity(this, fadeEffect, curtain));
        entities.add(new LevelClearedEntity(this, fadeEffect, curtain));
        entities.add(fadeEffect);
    }


    private void createAllLevelEntities() {
        levelEntities.add(new BackgroundEntity(this));
        
        levelEntities.add(new PetEntity(this, curtain));
        // air cushions
        for (AirCushion airCushion : model.getAirCushions()) {
            levelEntities.add(new AirCushionEntity(this, airCushion));
        }
        // ropes
        for (Rope rope : model.getRopes()) {
            levelEntities.add(new RopeEntity(this, rope));
        }
        // pin ropes
        for (PinRope pinRope : model.getPinRopes()) {
            levelEntities.add(new PinRopeEntity(this, pinRope));
        }
        // spikes
        for (Spikes spikes : model.getSpikesList()) {
            levelEntities.add(new SpikesEntity(this, spikes));
        }
        // candy
        levelEntities.add(new CandyEntity(this));
        // stars
        for (Star star : model.getStars()) {
            levelEntities.add(new StarEntity(this, star));
        }
        // bubbles
        for (Bubble bubble : model.getBubbles()) {
            levelEntities.add(new BubbleEntity(this, bubble));
        }
    }

    private void startAllEntities() {
        for (Entity entity : entities) {
            entity.start();
        }
    }
    
    private void startAllLevelEntities() {
        for (Entity entity : levelEntities) {
            entity.start();
        }
    }

    public void update() {
        for (Entity entity : levelEntities) {
            entity.update();
        }
        for (Entity entity : entities) {
            entity.update();
        }
    }
    
    public void updateFixed() {
        if (Mouse.pressed) {
            List<Point> trail = model.getSlashTrail().getTrail();
            if (trail.size() > 0) {
                Point p = trail.get(trail.size() - 1);
                if (p != null && p.x >= 0 && p.y >= 0) {
                    model.addSlashTrail((int) (p.x + 0.5 * (Mouse.x - p.x)), (int) (p.y + 0.5 * (Mouse.y - p.y)));
                }
                model.addSlashTrail((int) Mouse.x, (int) Mouse.y);
            }
        }
        else {
            model.addSlashTrail(-1, -1);
        }
        for (Entity entity : levelEntities) {
            entity.updateFixed();
        }
        for (Entity entity : entities) {
            entity.updateFixed();
        }
        model.update();
    }
    
    public void draw(Graphics2D g) {
        for (Entity entity : levelEntities) {
            if (entity.isVisible()) {
                entity.draw(g);
            }
        }
        for (Entity entity : entities) {
            if (entity.isVisible()) {
                entity.draw(g);
            }
        }
        
        // model.drawDebug(g);
        
        model.getSlashTrail().drawDebug(g);
    }
    
    // --- game flow ---

    public void startLevel(int level) {
        currentLevel = level;
        model.startLevel("/res/level_" + level + ".txt");
        levelEntities.clear();
        createAllLevelEntities();
        startAllLevelEntities();
        setState(PLAYING);
    }

    public void replayLevel() {
        startLevel(currentLevel);
    }

    public void backToTitle() {
        setState(TITLE);
    }

    public void nextLevel() {
        startLevel(currentLevel + 1);
    }

    
}
