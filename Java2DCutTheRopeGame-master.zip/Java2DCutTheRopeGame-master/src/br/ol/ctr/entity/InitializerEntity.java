package br.ol.ctr.entity;

import br.ol.ctr.core.Entity;
import br.ol.ctr.core.Scene;
import static br.ol.ctr.core.Scene.GameState.*;
import java.awt.Color;

/**
 * InitializerEntity class.
 * 
 * @author Leonardo Ono (ono.leo@gmail.com)
 */
public class InitializerEntity extends Entity {

    private FadeEffectEntity fadeEffect;
    
    public InitializerEntity(Scene scene, FadeEffectEntity fadeEffect) {
        super(scene);
        this.fadeEffect = fadeEffect;
    }

    @Override
    protected void updateFixedInitializing() {
        switch (instructionPointer) {
            case 0:
                
//                if (1 == 1) {
//                    scene.setState(TITLE);
//                    return;
//                }
                
                setCurrentWaitTime();
                instructionPointer = 1;
            case 1:
                if (!checkPassedTime(3)) {
                    return;
                }
                fadeEffect.setTargetColor(Color.WHITE);
                fadeEffect.fadeOut();
                instructionPointer = 2;
            case 2:
                if (!fadeEffect.fadeEffectFinished()) {
                    return;
                }
                scene.setState(OL_PRESENTS);
        }
    }

}
