package br.ol.ctr.entity;

import br.ol.ctr.core.Entity;
import br.ol.ctr.core.Scene;
import br.ol.ctr.core.Scene.GameState;
import static br.ol.ctr.core.Scene.GameState.*;
import br.ol.ctr.model.SlashTrail;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

/**
 * OLPresentsEntity class.
 *
 * @author Leonardo Ono (ono.leo@gmail.com)
 */
public class OLPresentsEntity extends Entity {

    private FadeEffectEntity fadeEffect;

    private SlashTrail trail = new SlashTrail(25, 0.4);
    private List<Point> points = new ArrayList<Point>();
    private int handWriteEffectIndex;
    private boolean handWriteEffectFinished;
    
    private BufferedImage cover;
    private double coverX = -50;

    public OLPresentsEntity(Scene scene, FadeEffectEntity fadeEffect) {
        super(scene);
        cover = loadImageFromResource("/res/ol_presents_0.png");
        loadImageFromResource("/res/ol_presents.png");
        this.fadeEffect = fadeEffect;
        addPoints();
        trail.setColor(new Color(230, 230, 230));
    }

    private void addPoints() {
        points.add(new Point(291, 341));
        points.add(new Point(291, 341));
        points.add(new Point(291, 341));
        points.add(new Point(291, 341));
        points.add(new Point(291, 341));
        points.add(new Point(289, 337));
        points.add(new Point(288, 334));
        points.add(new Point(288, 331));
        points.add(new Point(288, 331));
        points.add(new Point(289, 327));
        points.add(new Point(290, 325));
        points.add(new Point(292, 322));
        points.add(new Point(295, 318));
        points.add(new Point(298, 316));
        points.add(new Point(299, 316));
        points.add(new Point(302, 314));
        points.add(new Point(306, 314));
        points.add(new Point(307, 314));
        points.add(new Point(308, 314));
        points.add(new Point(309, 314));
        points.add(new Point(310, 315));
        points.add(new Point(311, 319));
        points.add(new Point(311, 321));
        points.add(new Point(311, 323));
        points.add(new Point(309, 328));
        points.add(new Point(307, 330));
        points.add(new Point(303, 332));
        points.add(new Point(302, 334));
        points.add(new Point(298, 336));
        points.add(new Point(295, 338));
        points.add(new Point(292, 340));
        points.add(new Point(289, 341));
        points.add(new Point(287, 341));
        points.add(new Point(284, 341));
        points.add(new Point(282, 340));
        points.add(new Point(279, 338));
        points.add(new Point(276, 335));
        points.add(new Point(275, 333));
        points.add(new Point(273, 329));
        points.add(new Point(273, 327));
        points.add(new Point(273, 323));
        points.add(new Point(274, 317));
        points.add(new Point(275, 314));
        points.add(new Point(280, 311));
        points.add(new Point(287, 306));
        points.add(new Point(291, 303));
        points.add(new Point(296, 302));
        points.add(new Point(305, 300));
        points.add(new Point(312, 300));
        points.add(new Point(319, 300));
        points.add(new Point(333, 302));
        points.add(new Point(337, 303));
        points.add(new Point(340, 305));
        points.add(new Point(342, 308));
        points.add(new Point(343, 311));
        points.add(new Point(343, 316));
        points.add(new Point(343, 320));
        points.add(new Point(342, 324));
        points.add(new Point(340, 327));
        points.add(new Point(335, 329));
        points.add(new Point(331, 331));
        points.add(new Point(328, 331));
        points.add(new Point(324, 330));
        points.add(new Point(320, 328));
        points.add(new Point(318, 326));
        points.add(new Point(318, 324));
        points.add(new Point(318, 322));
        points.add(new Point(321, 320));
        points.add(new Point(325, 318));
        points.add(new Point(328, 317));
        points.add(new Point(331, 317));
        points.add(new Point(334, 317));
        points.add(new Point(340, 318));
        points.add(new Point(346, 319));
        points.add(new Point(354, 319));
        points.add(new Point(360, 319));
        points.add(new Point(366, 318));
        points.add(new Point(369, 315));
        points.add(new Point(371, 312));
        points.add(new Point(372, 309));
        points.add(new Point(372, 306));
        points.add(new Point(370, 305));
        points.add(new Point(366, 303));
        points.add(new Point(361, 301));
        points.add(new Point(356, 300));
        points.add(new Point(352, 300));
        points.add(new Point(349, 300));
        points.add(new Point(345, 300));
        points.add(new Point(341, 302));
        points.add(new Point(335, 307));
        points.add(new Point(331, 309));
        points.add(new Point(329, 311));
        points.add(new Point(324, 317));
        points.add(new Point(320, 322));
        points.add(new Point(316, 328));
        points.add(new Point(310, 336));
        points.add(new Point(306, 342));
        points.add(new Point(300, 349));
        points.add(new Point(292, 356));
        points.add(new Point(283, 360));
        points.add(new Point(276, 362));
        points.add(new Point(269, 362));
        points.add(new Point(267, 362));
        points.add(new Point(265, 361));
        points.add(new Point(264, 356));
        points.add(new Point(264, 353));
        points.add(new Point(265, 350));
        points.add(new Point(265, 347));
        points.add(new Point(267, 346));
        points.add(new Point(268, 345));
        points.add(new Point(271, 344));
        points.add(new Point(273, 344));
        points.add(new Point(276, 344));
        points.add(new Point(282, 344));
        points.add(new Point(288, 344));
        points.add(new Point(293, 344));
        points.add(new Point(303, 345));
        points.add(new Point(311, 345));
        points.add(new Point(317, 345));
        points.add(new Point(326, 345));
        points.add(new Point(331, 345));
        points.add(new Point(337, 343));
        points.add(new Point(344, 340));
        points.add(new Point(348, 339));
        points.add(new Point(350, 337));
        points.add(new Point(351, 335));
        points.add(new Point(352, 334));
        points.add(new Point(352, 334));
        points.add(new Point(352, 334));
        points.add(new Point(351, 337));
        points.add(new Point(346, 344));
        points.add(new Point(341, 352));
        points.add(new Point(337, 356));
        points.add(new Point(337, 359));
        points.add(new Point(336, 360));
        points.add(new Point(336, 360));
        points.add(new Point(336, 360));
        points.add(new Point(339, 355));
        points.add(new Point(342, 351));
        points.add(new Point(348, 345));
        points.add(new Point(355, 338));
        points.add(new Point(358, 336));
        points.add(new Point(363, 335));
        points.add(new Point(364, 335));
        points.add(new Point(364, 335));
        points.add(new Point(365, 335));
        points.add(new Point(365, 337));
        points.add(new Point(361, 342));
        points.add(new Point(356, 346));
        points.add(new Point(352, 348));
        points.add(new Point(351, 349));
        points.add(new Point(351, 349));
        points.add(new Point(350, 349));
        points.add(new Point(350, 347));
        points.add(new Point(352, 346));
        points.add(new Point(352, 346));
        points.add(new Point(354, 347));
        points.add(new Point(355, 349));
        points.add(new Point(357, 351));
        points.add(new Point(360, 352));
        points.add(new Point(366, 352));
        points.add(new Point(369, 350));
        points.add(new Point(374, 349));
        points.add(new Point(382, 346));
        points.add(new Point(385, 345));
        points.add(new Point(390, 343));
        points.add(new Point(391, 340));
        points.add(new Point(391, 340));
        points.add(new Point(389, 339));
        points.add(new Point(386, 338));
        points.add(new Point(384, 338));
        points.add(new Point(380, 338));
        points.add(new Point(377, 339));
        points.add(new Point(372, 340));
        points.add(new Point(368, 344));
        points.add(new Point(366, 350));
        points.add(new Point(364, 353));
        points.add(new Point(365, 356));
        points.add(new Point(367, 357));
        points.add(new Point(370, 357));
        points.add(new Point(375, 357));
        points.add(new Point(379, 357));
        points.add(new Point(383, 355));
        points.add(new Point(388, 352));
        points.add(new Point(394, 345));
        points.add(new Point(400, 339));
        points.add(new Point(406, 334));
        points.add(new Point(409, 329));
        points.add(new Point(410, 328));
        points.add(new Point(411, 328));
        points.add(new Point(412, 328));
        points.add(new Point(412, 328));
        points.add(new Point(411, 333));
        points.add(new Point(408, 340));
        points.add(new Point(407, 345));
        points.add(new Point(406, 350));
        points.add(new Point(404, 356));
        points.add(new Point(402, 358));
        points.add(new Point(399, 359));
        points.add(new Point(391, 360));
        points.add(new Point(385, 359));
        points.add(new Point(385, 356));
        points.add(new Point(387, 355));
        points.add(new Point(388, 354));
        points.add(new Point(390, 354));
        points.add(new Point(393, 355));
        points.add(new Point(397, 356));
        points.add(new Point(405, 355));
        points.add(new Point(409, 352));
        points.add(new Point(412, 350));
        points.add(new Point(417, 348));
        points.add(new Point(425, 347));
        points.add(new Point(432, 346));
        points.add(new Point(435, 343));
        points.add(new Point(437, 340));
        points.add(new Point(437, 338));
        points.add(new Point(437, 337));
        points.add(new Point(434, 337));
        points.add(new Point(429, 337));
        points.add(new Point(423, 341));
        points.add(new Point(419, 344));
        points.add(new Point(417, 347));
        points.add(new Point(415, 350));
        points.add(new Point(415, 354));
        points.add(new Point(415, 356));
        points.add(new Point(417, 356));
        points.add(new Point(420, 356));
        points.add(new Point(424, 356));
        points.add(new Point(429, 356));
        points.add(new Point(433, 350));
        points.add(new Point(436, 347));
        points.add(new Point(442, 342));
        points.add(new Point(445, 339));
        points.add(new Point(447, 337));
        points.add(new Point(450, 337));
        points.add(new Point(450, 337));
        points.add(new Point(450, 339));
        points.add(new Point(448, 347));
        points.add(new Point(443, 354));
        points.add(new Point(440, 358));
        points.add(new Point(440, 359));
        points.add(new Point(441, 358));
        points.add(new Point(445, 354));
        points.add(new Point(448, 351));
        points.add(new Point(453, 345));
        points.add(new Point(458, 343));
        points.add(new Point(466, 342));
        points.add(new Point(466, 342));
        points.add(new Point(465, 344));
        points.add(new Point(462, 349));
        points.add(new Point(458, 354));
        points.add(new Point(456, 357));
        points.add(new Point(456, 358));
        points.add(new Point(459, 358));
        points.add(new Point(464, 357));
        points.add(new Point(469, 352));
        points.add(new Point(474, 345));
        points.add(new Point(478, 340));
        points.add(new Point(485, 334));
        points.add(new Point(488, 329));
        points.add(new Point(490, 325));
        points.add(new Point(492, 323));
        points.add(new Point(493, 323));
        points.add(new Point(493, 323));
        points.add(new Point(492, 325));
        points.add(new Point(491, 333));
        points.add(new Point(487, 342));
        points.add(new Point(482, 355));
        points.add(new Point(480, 361));
        points.add(new Point(480, 363));
        points.add(new Point(480, 362));
        points.add(new Point(485, 357));
        points.add(new Point(491, 350));
        points.add(new Point(497, 342));
        points.add(new Point(501, 336));
        points.add(new Point(503, 330));
        points.add(new Point(503, 329));
        points.add(new Point(504, 327));
        points.add(new Point(505, 327));
        points.add(new Point(506, 331));
        points.add(new Point(506, 338));
        points.add(new Point(504, 346));
        points.add(new Point(502, 352));
        points.add(new Point(500, 355));
        points.add(new Point(497, 357));
        points.add(new Point(491, 358));
        points.add(new Point(486, 356));
        points.add(new Point(482, 352));
        points.add(new Point(477, 346));
        points.add(new Point(476, 345));
        points.add(new Point(474, 341));
        points.add(new Point(474, 341));
        points.add(new Point(475, 341));
        points.add(new Point(483, 340));
        points.add(new Point(494, 339));
        points.add(new Point(564, 339));
        points.add(new Point(584, 339));
    }

    @Override
    protected void updateFixedOLPresents() {
        switch (instructionPointer) {
            case 0:
                setCurrentWaitTime();
                instructionPointer = 1;
            case 1:
                if (!checkPassedTime(1)) {
                    return;
                }
                fadeEffect.fadeIn();
                instructionPointer = 2;
            case 2:
                if (!fadeEffect.fadeEffectFinished()) {
                    return;
                }
                handWriteEffectIndex = 0;
                handWriteEffectFinished = false;
                instructionPointer = 3;
            case 3:
                updateHandWriteTrail();
                if (handWriteEffectFinished) {
                    setCurrentWaitTime();
                    instructionPointer = 4;
                }
                return;
            case 4:
                if (!checkPassedTime(5)) {
                    updateHandWriteTrail();
                    return;
                }
                fadeEffect.setTargetColor(Color.BLACK);
                fadeEffect.fadeOut();
                instructionPointer = 5;
            case 5:
                if (!fadeEffect.fadeEffectFinished()) {
                    return;
                }
                scene.setState(TITLE);
        }
    }

    private void updateHandWriteTrail() {
        int r = 3;
        if (handWriteEffectIndex < points.size() - (r - 1))  {
            for (int k = 0; k < r; k++) {
                Point p = points.get(handWriteEffectIndex++);
                // index += r;
                trail.addTrail(p.x, p.y);
            }
        }
        else {
            trail.addTrail(-1, -1);
            handWriteEffectFinished = true;
        }

        coverX += 2.65;
    }
    
    @Override
    public void draw(Graphics2D g) {
        g.drawImage(image, 0, 0, null);
        g.drawImage(cover, (int) coverX, 286, null);
        trail.drawDebug(g);
    }

    @Override
    public void gameStateChanged(GameState newGameState) {
        visible = false;
        if (newGameState == OL_PRESENTS) {
            visible = true;
            instructionPointer = 0;
        }
    }

}
