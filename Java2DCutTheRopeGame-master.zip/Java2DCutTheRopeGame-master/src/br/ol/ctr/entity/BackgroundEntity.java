package br.ol.ctr.entity;

import br.ol.ctr.core.Entity;
import br.ol.ctr.core.FontRenderer;
import br.ol.ctr.core.Scene;
import br.ol.ctr.core.Scene.GameState;
import java.awt.Graphics2D;

/**
 * BackgroundEntity class.
 * 
 * @author Leonardo Ono (ono.leo@gmail.com)
 */
public class BackgroundEntity extends Entity {
    
    public BackgroundEntity(Scene scene) {
        super(scene);
    }

    @Override
    public void start() {
        loadImageFromResource("/res/background.png");
    }

    @Override
    public void gameStateChanged(GameState newGameState) {
        visible = (newGameState != GameState.INITIALIZING) 
                && (newGameState != GameState.OL_PRESENTS)
                && (newGameState != GameState.TITLE);
    }
    
}
