package br.ol.ctr.entity;

import br.ol.ctr.core.Animation;
import br.ol.ctr.core.Entity;
import br.ol.ctr.core.Scene;
import br.ol.ctr.model.AirCushion;
import br.ol.ctr.model.AirCushionListener;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;

/**
 * AirCushionEntity class.
 * 
 * @author Leonardo Ono (ono.leo@gmail.com)
 */
public class AirCushionEntity extends Entity implements AirCushionListener {
    
    private AirCushion airCushion;
    // private AffineTransform transform = new AffineTransform();
    private Animation animation;
    
    public AirCushionEntity(Scene scene, AirCushion airCushion) {
        super(scene);
        this.airCushion = airCushion;
        airCushion.addListener(this);
        //loadImageFromResource("/res/air_cushion2.png");
        animation = new Animation();
        loadAllAnimations();
    }
    
    private void loadAllAnimations() {
        animation.addFrames("pump", "pump", 0, 5, 0, 0, false, 8);
        animation.selectAnimation("pump");
        animation.setCurrentFrame(5);
    }
    
    @Override
    public void update() {
        animation.update();
    }

    @Override
    public void draw(Graphics2D g) {
        //transform.setToIdentity();
        //transform.translate(airCushion.getPosition().x, airCushion.getPosition().y);
        //transform.rotate(airCushion.getDirection() * Math.toRadians(90));
        //transform.translate(-image.getWidth() / 2, -image.getHeight() / 2);
        //g.drawImage(image, transform, null);
        AffineTransform originalTransform = g.getTransform();
        g.translate(airCushion.getPosition().x, airCushion.getPosition().y);
        g.rotate((1 + airCushion.getDirection()) * Math.toRadians(90));
        g.translate(-48, -64);
        animation.draw(g);
        g.setTransform(originalTransform);
    }
    
    @Override
    public void gameStateChanged(Scene.GameState newGameState) {
        visible = newGameState == Scene.GameState.PLAYING;
    }    

    @Override
    public void onAirCushionFire() {
        animation.selectAnimation("pump");
    }
    
}
