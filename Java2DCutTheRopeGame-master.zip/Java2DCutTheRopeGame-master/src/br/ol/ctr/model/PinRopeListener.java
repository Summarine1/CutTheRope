package br.ol.ctr.model;

/**
 *
 * @author leonardo
 */
public interface PinRopeListener {

    public void onRopeCreated(Rope rope);
    
}
