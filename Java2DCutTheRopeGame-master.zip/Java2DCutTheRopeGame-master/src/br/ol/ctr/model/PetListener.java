package br.ol.ctr.model;

/**
 *
 * @author leonardo
 */
public interface PetListener {

    public void onCandyEaten();
    public void onCandyClose();
    public void onCandyEscaped();
    
}
