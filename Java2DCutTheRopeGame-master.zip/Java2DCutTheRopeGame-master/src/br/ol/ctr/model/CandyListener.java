package br.ol.ctr.model;

/**
 *
 * @author leonardo
 */
public interface CandyListener {

    public void onCandyDestroyed();
    
}
