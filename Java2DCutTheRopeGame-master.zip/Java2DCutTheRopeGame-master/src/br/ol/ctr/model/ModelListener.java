package br.ol.ctr.model;

/**
 *
 * @author leonardo
 */
public interface ModelListener {

    public void onFailure();
    public void onLevelCleared();
    
}
