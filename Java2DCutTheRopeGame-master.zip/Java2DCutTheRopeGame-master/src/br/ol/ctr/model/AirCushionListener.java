package br.ol.ctr.model;

/**
 *
 * @author leonardo
 */
public interface AirCushionListener {

    public void onAirCushionFire();
    
}
