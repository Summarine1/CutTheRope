package br.ol.ctr.model;

/**
 *
 * @author leonardo
 */
public interface StarListener {

    public void onStarCaught();
    
}
