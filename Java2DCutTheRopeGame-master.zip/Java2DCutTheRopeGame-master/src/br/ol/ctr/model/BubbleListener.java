package br.ol.ctr.model;

/**
 *
 * @author leonardo
 */
public interface BubbleListener {

    public void onBurst();
    public void onCandyCaught();
    
}
