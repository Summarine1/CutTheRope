package br.ol.ctr.ui;

/**
 *
 * @author leonardo
 */
public interface ButtonListener {
    
    public void onClick();
    
}
